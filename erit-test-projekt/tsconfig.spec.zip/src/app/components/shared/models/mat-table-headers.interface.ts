export interface MatTableHeaders {
  header1: string;
  header2: string;
  header3: string;
  header4: string;
  header5: string;
}
