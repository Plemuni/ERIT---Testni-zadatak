// import { ComponentFixture, TestBed } from '@angular/core/testing';
// import { IconCardComponent } from './icon-card.component';
// import { MessagesService } from '../../../../services/messages/messages.service';
// import { PinnedMessagesService } from '../../../../services/messages/pinned-messages/pinned-messages.service';
// import { WarningsService } from '../../../../services/warnings/warnings.service';
// import { ScreenService } from '../../../../services/screen/screen.service';
// import { BehaviorSubject, of } from 'rxjs';
// import { IconCardItem } from '../../models/icon-card.interface';

// describe('IconCardComponent', () => {
//   let component: IconCardComponent;
//   let fixture: ComponentFixture<IconCardComponent>;

//   let mockMessagesService: Partial<MessagesService>;
//   let mockPinnedMessagesService: Partial<PinnedMessagesService>;
//   let mockWarningsService: Partial<WarningsService>;
//   let mockScreenService: Partial<ScreenService>;

//   beforeEach(async () => {
//     mockMessagesService = {
//       messagesSubject$: new BehaviorSubject<IconCardItem[]>([
//         {
//           /* Test data for new messages */
//         } as IconCardItem,
//       ]),
//     };
//     mockPinnedMessagesService = {
//       pinnedMessagesSubject$: new BehaviorSubject<IconCardItem[]>([
//         {
//           /* Test data for pinned messages */
//         } as IconCardItem,
//       ]),
//     };
//     mockWarningsService = {
//       warningsSubject$: new BehaviorSubject<IconCardItem[]>([
//         {
//           /* Test data for warnings */
//         } as IconCardItem,
//       ]),
//     };
//     mockScreenService = {
//       isMobileSubject$: new BehaviorSubject(false),
//     };

//     await TestBed.configureTestingModule({
//       providers: [
//         { provide: MessagesService, useValue: mockMessagesService },
//         { provide: PinnedMessagesService, useValue: mockPinnedMessagesService },
//         { provide: WarningsService, useValue: mockWarningsService },
//         { provide: ScreenService, useValue: mockScreenService },
//       ],
//     }).compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(IconCardComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should display "No messages." if items are empty', () => {
//     component.items = [];
//     fixture.detectChanges();
//     const noMessagesText = fixture.nativeElement.querySelector('b');
//     expect(noMessagesText.textContent).toContain('No messages.');
//   });

//   it('should pin a message when pin button is clicked', () => {
//     const item = {
//       id: 1,
//       itemIcon: {},
//       dates: [],
//       text: { content: 'Test' },
//       buttons: [{ src: 'pin.png', pin: 'pin' }],
//     } as IconCardItem;
//     component.onPinClicked(item, 'pin');
//     fixture.detectChanges();
//     // Assert the pinning functionality, e.g., checking if pinnedMessagesSubject$ has updated
//   });

//   it('should unpin a message when unpin button is clicked', () => {
//     const item = {
//       id: 1,
//       itemIcon: {},
//       dates: [],
//       text: { content: 'Test' },
//       buttons: [{ src: 'pinned.png', pin: 'unpin' }],
//     } as IconCardItem;
//     component.onPinClicked(item, 'unpin');
//     fixture.detectChanges();
//     // Assert the unpinning functionality, e.g., checking if pinnedMessagesSubject$ has updated
//   });

//   it('should toggle card collapse on icon click', () => {
//     component.collapsed = false;
//     component.onToggleCardCollapse();
//     expect(component.collapsed).toBeTrue();
//     component.onToggleCardCollapse();
//     expect(component.collapsed).toBeFalse();
//   });
// });
