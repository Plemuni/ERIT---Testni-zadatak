// import { ComponentFixture, TestBed } from '@angular/core/testing';
// import { DashboardComponent } from './dashboard.component';
// import { BreakpointObserver } from '@angular/cdk/layout';
// import { BehaviorSubject, of } from 'rxjs';
// import { ScreenService } from '../../services/screen/screen.service';
// import { MessagesService } from '../../services/messages/messages.service';
// import { WarningsService } from '../../services/warnings/warnings.service';
// import { PinnedMessagesService } from '../../services/messages/pinned-messages/pinned-messages.service';
// import { RosterService } from '../../services/roster/roster.service';
// import { ChangeRequestsReceivedService } from '../../services/change-requests/change-requests-received/change-requests-received.service';
// import { ChangeRequestsSentService } from '../../services/change-requests/change-requests-sent/change-requests-sent.service';
// import { HoursService } from '../../services/hours/hours.service';
// import { MessageCardItem } from '../shared/models/icon-card.interface';
// import { RosterCardData } from '../shared/models/roster-card.interface';
// import { WarningsCardItem } from '../shared/models/warnings-card.interface';
// import {
//   ChangeRequestItem,
//   WorkTimeItem,
// } from '../shared/models/data-card.interface';
// import { NO_ERRORS_SCHEMA, Component } from '@angular/core';

// // Mock IconCardComponent
// @Component({
//   selector: 'app-icon-card',
//   template: '<div></div>',
// })
// class MockIconCardComponent {}

// // Mock RosterCardComponent
// @Component({
//   selector: 'app-roster-card',
//   template: '<div></div>',
// })
// class MockRosterCardComponent {}

// // Mock TableCardComponent
// @Component({
//   selector: 'app-table-card',
//   template: '<div></div>',
// })
// class MockTableCardComponent {}

// describe('DashboardComponent', () => {
//   let component: DashboardComponent;
//   let fixture: ComponentFixture<DashboardComponent>;

//   // Mock services as BehaviorSubjects to simulate real data
//   const mockBreakpointObserver = {
//     observe: jasmine.createSpy().and.returnValue(
//       of({
//         breakpoints: {
//           '(max-width: 600px)': false,
//           '(min-width: 601px) and (max-width: 1024px)': false,
//         },
//       })
//     ),
//   };

//   const mockScreenService = {
//     setIsMobile: jasmine.createSpy(),
//     setIsTablet: jasmine.createSpy(),
//   };

//   const mockMessagesService = {
//     messagesSubject$: new BehaviorSubject<MessageCardItem[]>([]),
//   };

//   const mockWarningsService = {
//     warningsSubject$: new BehaviorSubject<WarningsCardItem[]>([]),
//   };

//   const mockPinnedMessagesService = {
//     pinnedMessagesSubject$: new BehaviorSubject<MessageCardItem[]>([]),
//   };

//   const mockRosterService = {
//     changeRequestsReceived$: new BehaviorSubject<RosterCardData[]>([]),
//   };

//   const mockChangeRequestsReceivedService = {
//     changeRequestsReceived$: new BehaviorSubject<ChangeRequestItem[]>([]),
//   };

//   const mockChangeRequestsSentService = {
//     changeRequestsReceived$: new BehaviorSubject<ChangeRequestItem[]>([]),
//   };

//   const mockHoursService = {
//     changeRequestsReceived$: new BehaviorSubject<WorkTimeItem[]>([]),
//   };

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       imports: [DashboardComponent],
//       declarations: [
//         MockIconCardComponent,
//         MockRosterCardComponent,
//         MockTableCardComponent,
//       ],
//       providers: [
//         { provide: BreakpointObserver, useValue: mockBreakpointObserver },
//         { provide: ScreenService, useValue: mockScreenService },
//         { provide: MessagesService, useValue: mockMessagesService },
//         { provide: WarningsService, useValue: mockWarningsService },
//         { provide: PinnedMessagesService, useValue: mockPinnedMessagesService },
//         { provide: RosterService, useValue: mockRosterService },
//         {
//           provide: ChangeRequestsReceivedService,
//           useValue: mockChangeRequestsReceivedService,
//         },
//         {
//           provide: ChangeRequestsSentService,
//           useValue: mockChangeRequestsSentService,
//         },
//         { provide: HoursService, useValue: mockHoursService },
//       ],
//       schemas: [NO_ERRORS_SCHEMA], // Ignore unknown elements and attributes
//     }).compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DashboardComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create the component', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should set isMobile and isTablet based on BreakpointObserver', () => {
//     // Simulate different screen sizes
//     (mockBreakpointObserver.observe as jasmine.Spy).and.returnValue(
//       of({
//         breakpoints: {
//           '(max-width: 600px)': true,
//           '(min-width: 601px) and (max-width: 1024px)': false,
//         },
//       })
//     );
//     component.ngOnInit();
//     expect(component.isMobile).toBeTrue();
//     expect(component.isTablet).toBeFalse();
//   });

//   it('should call screenService methods to update screen status', () => {
//     component.ngOnInit();
//     expect(mockScreenService.setIsMobile).toHaveBeenCalledWith(
//       component.isMobile
//     );
//     expect(mockScreenService.setIsTablet).toHaveBeenCalledWith(
//       component.isTablet
//     );
//   });
// });
